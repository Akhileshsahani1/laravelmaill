<?php

namespace App\Http\Controllers\Practice;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PracticeDetailController extends Controller
{
    //
}
