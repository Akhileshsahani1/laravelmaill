<?php

namespace App\Http\Controllers\Practice;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Practice;
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;
use Illuminate\Support\Facades\Mail;

class PracticeController extends Controller {

    public function home() {
        return view( 'Practice.welcome' );
    }

    public function signup_view() {
        return view( 'Practice.signup' );
    }

    public function signUp( Request $request ) 
    {
        $request->validate( [
            'firstName' => 'required',
            'lastName' => 'required|max:255',
            'clinicName' => 'required',
            'email' => 'required|email|unique:users',
            'phoneNumber' => 'required|min:10',
            // 'password' => 'required|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/',
            'city'=>'required',
            'zipCode'=>'required'

        ] );
        $password = random_int(1000, 9999);
        dd($password);
        $data = Practice::create([  
                                'firstName' => $request->firstName,
                                'lastName' =>$request->lastName,
                                'clinicName' =>$request->clinicName,
                                'email' =>$request->email,
                                'phoneNumber' =>$request->phoneNumber,
                                'password' =>$request->password,
                                'city'=>$request->city,
                                'zipCode'=>$request->zipCode
                            ]); 
      if($data->save())
      {
        return view( 'Practice.signupProfessional' );
      }

      
        

    }

    public function composeEmail(Request $request) {
         $data =[
            'name'=>'akhilesh','data'=>'hello akhilesh'
         ];
         $user['to']='akhileshsahani48@gmail.com';
        $td= Mail::send('mail',$data,function($messages) use($user){
            $messages->to($user['to']);
            $messages->subject('Hello dev');
         });
       if($td)
       {
          echo"mail sent successfully.";
       }
    }
    // public function index()
    // {
    //     $randomNumber = random_int(1000, 9999);
   
    //     return  $randomNumber;
    // }

    public function Authenticate( Request $request ) {

    }

    public function signupProfessional( Request $request ) {
        return view( 'Practice.signupProfessional' );
    }

    public function details( Request $request ) {
        return view( 'Practice.professionalDetails' );
    }

    public function Authentication( Request $request ) {
        dd( 'login' );
    }
}
