<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PracticeAuthenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    protected function redirectTo($request)
    {
        if (! $request->expectsJson()) {
          
            return redirect()->route('practice.auth');
        }
    }
     protected function authenticate($request, array $guards)
     {
        
            if ($this->auth->guard('practice')->check()) {
                return $this->auth->shouldUse('practice');
            }
        
        $this->unauthenticated($request, ['practice']);
    }
}
