<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="{{asset('Css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('Css/style.css')}}" />
    <title>Welcome Back</title>
  </head>

  <body>
    <main>
      <div class="row g-0 overflow-hidden">
        <div class="col-md-6 container position-relative">
          <div class="row">
            <div class="col-md-6 m-auto">
              <div class="mt-5 m-auto">
                <div class="text-center">
                  <div class="text-start my-5">
                    <img src="{{asset('Assets/logo.svg')}}" style="width: 100px" alt="" />
                  </div>
                  <div>
                    <h1 class="fw-bold mb-0">WELCOME BACK!</h1>
                    <p class="light-blue-color font-18">
                      Sign in to your account
                    </p>
                  </div>
                  <div class="">
                    <div class="position-relative mb-3">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Enter mail id"
                      />
                      <span class="input-icon"
                        ><i class="bi bi-envelope-fill"></i
                      ></span>
                    </div>
                    <div class="position-relative mb-3">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Enter password"
                      />
                      <span class="input-icon"
                        ><i class="bi bi-eye-fill"></i
                      ></span>
                    </div>
                    <div
                      class="mb-3 d-flex align-items-center justify-content-between"
                    >
                      <div class="">
                        <input type="checkbox" value="" id="flexCheckDefault" />
                        <label for="flexCheckDefault"> Keep me Signin </label>
                      </div>
                      <div>
                        <p class="m-0">Forgot Password?</p>
                      </div>
                    </div>
                    <div class=" my-5">
                      <div class="mb-3">
                        <button
                          class="w-100 button button-bg button-color fw-semibold"
                        >
                          Sign In
                        </button>
                      </div>
                      <div
                        class="mb-3 d-flex align-items-center justify-content-center px-2"
                      >
                        <div class="border w-25"></div>
                        <span class="bg-white px-1 font-14 fw-semibold"
                          >OR DON'T HAVE AN ACCOUNT</span
                        >
                        <div class="border w-25"></div>
                      </div>
                      <div class="mb-3">
                      
                        <button
                        class="w-100 button-outline button-color fw-semibold"
                        >
                        <a  href="{{route('signup_view')}}">
                          Sign Up
                          </a>
                        </button>
                       
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div  class="plus">
            <img src="{{asset('Assets/images/Icon material-add.svg')}}" alt="" />
          </div>
        </div>
        <div class="col-md-6">
          <div class="d-md-block  d-none" >
            <img
            src="{{asset('Assets/images/welcome.svg')}}"
            style="height:100vh; object-fit: cover;"
            alt=""
          />
          </div>
        </div>
      </div>
    </main>

    <script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('js/script.js')}}"></script>
  </body>
</html>
