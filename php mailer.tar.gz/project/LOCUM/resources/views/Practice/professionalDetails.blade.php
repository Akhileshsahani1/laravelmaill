<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="{{asset('Css/bootstrap.min.css')}}" />
  <link rel="stylesheet" href="{{asset('Css/style.css')}}" />
  <title>Sign Up</title>
</head>

<body>
  <main>
    <div class="row g-0 overflow-hidden">
      <div class="col-md-6 container position-relative">
        <div class="row">
          <div class="col-md-6 m-auto">
            <div class="mt-5 m-auto">
              <div class="text-center">
                <div class="text-start my-5">
                  <img src="{{asset('Assets/logo.svg')}}" style="width: 100px" alt="" />
                </div>
                <div>
                  <h1 class="fw-bold mb-0">Sign Up</h1>
                  <p class="light-blue-color font-18 mb-1">
                    Let's get you started!
                  </p>
                  <p class="yellow-color font-18 fw-bold">Step 3/3</p>
                </div>
                <div class="">
                 
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label" for="formControl">Language</label>
                    <label for="" class="opacity-40 font-16">Select Language</label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                   
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> English </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> French </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Germen </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="text-input mb-3">
                    <input type="text" id="formControlLg" class="form-control" placeholder="Enter Anticipated Average Daily Amount" />
                    <label class="text-input-label" for="formControlLg">Anticipated Average Daily Amount</label>
                    
                  </div>
                  
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label" for="formControl">Expected Cases/ Procedure types?</label>
                    <label for="" class="opacity-40 font-16">Select Expected Cases/ Procedure types?</label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                    
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Diagnostic/Preventative </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1">Endodontics </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Periodontics </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Hygiene/ Emergency </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1">Hygiene/ Emergency/ Simple Procedures</label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Hygiene/ Emergency/ All general Procedure</label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Oral Surgery </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1">Orthodontics </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Pedodontics </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="text-input mb-3">
                    <input type="text" id="formControlLg" class="form-control" placeholder="Enter Expected qualities in a Locum Tenen" />
                    <label class="text-input-label" for="formControlLg">Expected qualities in a Locum Tenen</label>
                   
                  </div>
                  
                 

                  <div class=" my-5">
                    <div class="mb-3">
                      <button class="w-100 button button-bg button-color fw-semibold">
                        Next
                      </button>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="plus">
          <img src="{{asset('Assets/images/Icon material-add.svg')}}" alt="" />
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="d-md-block  d-none" >
          <img src="{{asset('Assets/images/sign up.png')}}" style="height:100vh; object-fit: cover;" alt="" />
        </div>
      </div>
    </div>
  </main>

  <script src="{{asset('Js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('Js/script.js')}}"></script>
</body>

</html>