<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="{{asset('Css/bootstrap.min.css')}}" />
  <link rel="stylesheet" href="{{asset('Css/style.css')}}" />
  <title>Sign Up</title>
</head>

<body>
  <main>
    <div class="row g-0 overflow-hidden">
      <div class="col-md-6 container position-relative">
        <div class="row">
          <div class="col-md-6 m-auto">
            <div class="mt-5 m-auto">
              <div class="text-center">
                <div class="text-start my-5">
                  <img src="{{asset('Assets/logo.svg')}}" style="width: 100px" alt="" />
                </div>
                <div>
                  <h1 class="fw-bold mb-0">Sign Up</h1>
                  <p class="light-blue-color font-18 mb-1">
                    Let's get you started!
                  </p>
                  <p class="yellow-color font-18 fw-bold">Step 2/3</p>
                </div>
                <div class="">
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                      type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                      
                      <label class="text-input-label" for="formControl">Practice type</label>
                      <label for="" class="opacity-40 font-16">Select practice type</label>
                      <i class="bi bi-chevron-down"></i>
                    </button>
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> General Dentist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Hygienist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Endodontist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Oral Surgeon </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Orthodontist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Periodontist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Pedodontist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Prosthodontist </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                 
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label" for="formControl">Position type</label>
                    <label for="" class="opacity-40 font-16">Select position type</label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Temporary </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Permanent </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Temporary Possibly Permanent </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label text-capitalize" for="formControl">expected daily patient volume</label>
                    <label for="" class="opacity-40 font-16">Select expected daily patient volume</label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                   
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> 1-10 </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> 10-15 </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> 15+ </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label" for="formControl">Do you treat children?</label>
                    <label for="" class="opacity-40 font-16">Select do you treat children? </label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                   
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1">YES</label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1">NO</label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label" for="formControl">Expected daily working hours</label>
                    <label for="" class="opacity-40 font-16">Select expected daily working hours</label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                    
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> 4-8 hours </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> 8+ hours </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    
                    </ul>
                  </div>
                  <div class="dropdown mb-3">
                    <button class="text-input dropdown-toggle form-control d-flex justify-content-between align-items-center"
                    type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                    
                    <label class="text-input-label" for="formControl">Location of the Delivery System</label>
                    <label for="" class="opacity-40 font-16">Select Location of the Delivery System</label>
                    <i class="bi bi-chevron-down"></i>
                  </button>
                   
                    <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Left</label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Right </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#">
                          <div class="form-check d-flex align-items-center justify-content-between">
                            <label class="form-check-label" for="flexRadioDefault1"> Rear </label>
                            <input class="form-check-input" type="radio" name="flexRadioDefault"
                              id="flexRadioDefault1" />
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                 

                  <div class=" my-5">
                    <div class="mb-3">
                      <button class="w-100 button button-bg button-color fw-semibold">
                        <a href="{{route('professionalDetails')}}">
                        Next
                         </a>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="plus">
          <img src="{{asset('Assets/images/Icon material-add.svg')}}" alt="" />
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="d-md-block  d-none">
          <img src="{{asset('Assets/images/sign up.png')}}" style="height:100vh; object-fit: cover;" alt="" />
        </div>
      </div>
    </div>
  </main>

  <script src="{{asset('Js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('Js/script.js')}}"></script>
</body>

</html>