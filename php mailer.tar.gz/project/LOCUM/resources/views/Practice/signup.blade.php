<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="{{asset('Css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('Css/style.css')}}" />
    <title>Sign Up</title>
  </head>

  <body>
    <main>
      <div class="row g-0 overflow-hidden">
        <div class="col-md-6 container position-relative">
          <div class="row">
            <div class="col-md-6 m-auto">
              <div class="mt-5 m-auto">
                <div class="text-center">
                  <div class="text-start my-5">
                    <img src="{{asset('Assets/logo.svg')}}" style="width: 100px" alt="" />
                  </div>
                  <div>
                    <h1 class="fw-bold mb-0">Sign Up</h1>
                    <p class="light-blue-color font-18 mb-1">
                      Let's get you started!
                    </p>
                    <p class="yellow-color font-18 fw-bold">Step 1/3</p>
                  </div>
                  <div class="">
                    <form action="{{route('signupProfessional')}}" method="POST">
                       @csrf
                    <div class="text-input mb-3">
                      <input type="text" id="formControlLg" name="firstName" class="form-control" placeholder="Enter first name" />
                      <label class="text-input-label" for="formControlLg">First name</label>
                      <span class="input-icon"
                        ><i class="bi bi-person-fill"></i
                      ></span>
                      @if ($errors->has('firstName'))
                            <span class="text-danger">{{ $errors->first('firstName') }}</span>
                        @endif
                    </div>
                    <div class="text-input mb-3">
                      <input type="text" id="formControlLg" name="lastName" class="form-control" placeholder="Enter last name" />
                      <label class="text-input-label" for="formControlLg">Last name</label>
                      <span class="input-icon"
                        ><i class="bi bi-person-fill"></i
                      ></span>
                      @if ($errors->has('lastName'))
                            <span class="text-danger">{{ $errors->first('lastName') }}</span>
                        @endif
                    </div>
                    <div class="text-input mb-3">
                      <input type="text" id="formControlLg" name="clinicName" class="form-control" placeholder="Enter clinic name" />
                      <label class="text-input-label" for="formControlLg">Clinic name</label>
                      <span class="input-icon"
                        ><i class="bi bi-hospital-fill"></i
                      ></span>
                      @if ($errors->has('clinicName'))
                            <span class="text-danger">{{ $errors->first('clinicName') }}</span>
                        @endif
                    </div>
                    <div class="text-input mb-3">
                      <input type="email" id="formControlLg" name="email" class="form-control" placeholder="Enter email id" />
                      <label class="text-input-label" for="formControlLg">Email Id</label>
                      <span class="input-icon"
                        ><i class="bi bi-envelope-fill"></i
                      ></span>
                      @if ($errors->has('email'))
                            <span class="text-danger">{{ $errors->first('email') }}</span>
                        @endif
                    </div>
                    <div class="text-input mb-3">
                      <input type="tel" id="formControlLg" name="phoneNumber" class="form-control" placeholder="Enter phone number" />
                      <label class="text-input-label" for="formControlLg">Phone Number</label>
                      <span class="input-icon"
                        ><i class="bi bi-telephone-fill"></i
                      ></span>
                      @if ($errors->has('phoneNumber'))
                            <span class="text-danger">{{ $errors->first('phoneNumber') }}</span>
                        @endif
                    </div>
                    <div class="text-input mb-3">
                      <input type="text" id="formControlLg" name="city" class="form-control" placeholder="Enter city" />
                      <label class="text-input-label" for="formControlLg">City</label>
                      <span class="input-icon"
                        ><i class="bi bi-buildings-fill"></i
                      ></span>
                      @if ($errors->has('city'))
                            <span class="text-danger">{{ $errors->first('city') }}</span>
                        @endif
                    </div>
                    <div class="text-input mb-3">
                      <input type="text" id="formControlLg" name="zipCode" class="form-control" placeholder="Enter zip code" />
                      <label class="text-input-label" for="formControlLg">Zip Code</label>
                      <span class="input-icon"
                        ><i class="bi bi-building-fill"></i
                      ></span>
                      @if ($errors->has('zipCode'))
                            <span class="text-danger">{{ $errors->first('zipCode') }}</span>
                        @endif
                    </div>
                   
                   
                    <div class=" my-5">
                      <div class="mb-3">
                        <button type="submit"
                          class="w-100 button button-bg button-color fw-semibold"
                        >
                          Next
                        
                        </button>
                      </div>
                  </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div  class="plus">
            <img src="{{asset('Assets/images/Icon material-add.svg')}}" alt="" />
          </div>
        </div>
        <div class="col-md-6 ">
          <div class="d-md-block  d-none" >
            <img
            src="{{asset('Assets/images/sign up.png')}}"
            style="height:100vh; object-fit: cover;"
            alt=""
            
          />
          </div>
        </div>
      </div>
    </main>

    <script src="{{asset('Js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('Js/script.js')}}"></script>
  </body>
</html>
