<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Practice\PracticeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('Practice.signup');
// });

                 

Route::get('/mail',[PracticeController::class,'composeEmail']);

Route::group(['prefix' => 'practice'], function() {
    Route::group(['middleware' => 'practice.guest'], function(){
        Route::get('/welcome',[PracticeController::class,'home'])->name('practice.home');
        Route::get('/signup',[PracticeController::class,'signup_view'])->name('signup_view');
        Route::post('/signup/Professional',[PracticeController::class,'signUp'])->name('signupProfessional');
       
        // Route::get('Professional/details',[PracticeController::class,'details'])->name('professionalDetails');
        // Route::post('/authenticate',[PracticeController::class,'Authentication'])->name('practice.auth');
    });
    
    Route::group(['middleware'=> 'practice.auth'], function(){
       
        Route::get('/practic_dashboard','PracticeController@Dashboard')->name('practicedashboard');
        Route::get('/practicelogout','PracticeController@logout')->name('practicelogout');
        Route::get('/practicecalander','PracticeController@calander')->name('Practice.calander');
        Route::get('/practice_available','PracticeController@available')->name('Practice.available');
        Route::get('/available_data','PracticeController@providerdd');
        
        
        //Ajax data insert -------------------------------------
        Route::post('/PracticeCreate','PracticeController@store')->name('PracticeCreate');
        Route::delete('/practice/destroy/{id}','PracticeController@destroy')->name('practice.destroy');
        Route::patch('/calendar/update/{id}','PracticeController@update')->name('practice.update');

       
        
          
    });
});